<?php
/**
 * Plugin Name: Onliest - Required Plugin
 * Description: This contains the custom post types needed for the theme functionality
 * Version: 1.0.0
 * Author: esmet
 * Author URI: http://themeforest.net/user/esmet
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU
 * General Public License version 2, as published by the Free Software Foundation.  You may NOT assume
 * that you can use any other version of the GPL.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

function cdb_create_post_type_portfolios() {

    $labels = array(
        'name' => esc_html__( 'Portfolio','onliestwp'),
        'singular_name' => esc_html__( 'Portfolio','onliestwp' ),
        'rewrite' => array('slug' => esc_html__( 'portfolios','onliestwp' )),
        'add_new' => esc_html_x('Add New', 'portfolio', 'onliestwp'),
        'add_new_item' => esc_html__('Add New Portfolio','onliestwp'),
        'edit_item' => esc_html__('Edit Portfolio','onliestwp'),
        'new_item' => esc_html__('New Portfolio','onliestwp'),
        'view_item' => esc_html__('View Portfolio','onliestwp'),
        'search_items' => esc_html__('Search Portfolio','onliestwp'),
        'not_found' =>  esc_html__('No portfolios found','onliestwp'),
        'not_found_in_trash' => esc_html__('No portfolios found in Trash','onliestwp'),
        'parent_item_colon' => ''
    );

    $rewrite = array(
        'slug'                => 'portfolio',
        'with_front'          => false,
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'show_ui' => true,
        'menu_icon' => 'dashicons-schedule',
        'query_var' => true,
        'taxonomies' => array( 'post_tag' ),
        'rewrite' => $rewrite,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title','editor', 'excerpt', 'thumbnail', 'comments')
    );

    register_post_type('portfolio',$args);
    flush_rewrite_rules();

    $category_labels = array(
        'name' => esc_html__( 'Portfolio Categories', 'onliestwp'),
        'singular_name' => esc_html__( 'Portfolio Category', 'onliestwp'),
        'search_items' =>  esc_html__( 'Search Portfolio Categories', 'onliestwp'),
        'all_items' => esc_html__( 'All Portfolio Categories', 'onliestwp'),
        'parent_item' => esc_html__( 'Parent Portfolio Category', 'onliestwp'),
        'edit_item' => esc_html__( 'Edit Portfolio Category', 'onliestwp'),
        'update_item' => esc_html__( 'Update Portfolio Category', 'onliestwp'),
        'add_new_item' => esc_html__( 'Add New Portfolio Category', 'onliestwp'),
        'menu_name' => esc_html__( 'Portfolio Categories', 'onliestwp')
    );

    register_taxonomy("portfolio-category",
        array("portfolio"),
        array("hierarchical" => true,
            'labels' => $category_labels,
            'show_ui' => true,
            'query_var' => true,
            'rewrite' => array( 'slug' => 'portfolio-category' )
        ));

    /* Add Custom Columns */
    function cdb_column_value($column_name, $id) {
        if ($column_name == 'cdbpid') echo $id;
    }
    function cdb_column_add_clean($cols) {
        $cols['cdbpid'] = __('ID', 'onliestwp');
        return $cols;
    }

    add_filter("manage_portfolio_posts_custom_column", 'cdb_column_value', 10, 2);
    add_filter("manage_portfolio_posts_columns", 'cdb_column_add_clean', 10 );
}

/* Initialize Create Post Type Function */
add_action( 'init', 'cdb_create_post_type_portfolios', 10 );


/**
 * Author Social Links
 */
function custom_contactmethods( $contactmethods ) {

    $contactmethods['twitter']   = 'Twitter Username';
    $contactmethods['facebook']  = 'Facebook Username';
    $contactmethods['google']    = 'Google Plus Username';
    $contactmethods['tumblr']    = 'Tumblr Username';
    $contactmethods['instagram'] = 'Instagram Username';
    $contactmethods['pinterest'] = 'Pinterest Username';

    return $contactmethods;
}
add_filter('user_contactmethods','custom_contactmethods',10,1);